# Changelog

## [2.42.0](https://github.com/supabase/supabase-swift/compare/v2.41.1...v2.42.0) (2026-03-19)


### Features

* **storage:** implement setHeader method on storage client ([#910](https://github.com/supabase/supabase-swift/issues/910)) ([55a64a4](https://github.com/supabase/supabase-swift/commit/55a64a40350f4947da1b5e74ab051bbb3e734050))


### Bug Fixes

* **realtime:** use URLRequest headers instead of httpAdditionalHeaders for WebSocket ([#920](https://github.com/supabase/supabase-swift/issues/920)) ([47969d5](https://github.com/supabase/supabase-swift/commit/47969d52a871f5ef420e3134cc0e54ba66a3eeb8))

## [2.41.1](https://github.com/supabase/supabase-swift/compare/v2.41.0...v2.41.1) (2026-02-06)


### Bug Fixes

* **auth:** decode MFA unenroll response id field ([#905](https://github.com/supabase/supabase-swift/issues/905)) ([7f42d92](https://github.com/supabase/supabase-swift/commit/7f42d9291008aa8c3863e9f5e677009499676f37))

## [2.41.0](https://github.com/supabase/supabase-swift/compare/v2.40.0...v2.41.0) (2026-01-28)


### Features

* **ci:** enhance CI with format check, API stability, and success summary ([#887](https://github.com/supabase/supabase-swift/issues/887)) ([a15b888](https://github.com/supabase/supabase-swift/commit/a15b88809ca210693687bc7eefd937290b71d292))


### Bug Fixes

* improve Swift concurrency thread safety and documentation ([#891](https://github.com/supabase/supabase-swift/issues/891)) ([eb73450](https://github.com/supabase/supabase-swift/commit/eb73450d01ba61c9f3d2d51631d48a42d716cfe3))

## [2.40.0](https://github.com/supabase/supabase-swift/compare/v2.39.0...v2.40.0) (2026-01-13)


### Features

* **storage:** add support for additional query items in download method ([#871](https://github.com/supabase/supabase-swift/issues/871)) ([4b201af](https://github.com/supabase/supabase-swift/commit/4b201af8a993fbe0d74cdf5d6c81222efd5c519c))


### Bug Fixes

* **ci:** add GitHub App token generation to release workflow ([#879](https://github.com/supabase/supabase-swift/issues/879)) ([19d38f9](https://github.com/supabase/supabase-swift/commit/19d38f9273210ed85f4bed0008db2ebfc322baed))
* **functions:** sync auth headers on auth state change ([#878](https://github.com/supabase/supabase-swift/issues/878)) ([a219239](https://github.com/supabase/supabase-swift/commit/a219239515cd347800c070849311acc823f0394e))

## [2.39.0](https://github.com/supabase/supabase-swift/compare/v2.38.1...v2.39.0) (2025-12-16)


### Features

* **auth:** add X (OAuth 2.0) provider ([#872](https://github.com/supabase/supabase-swift/issues/872)) ([61573b7](https://github.com/supabase/supabase-swift/commit/61573b79c62d91b763b3d45ba45203d92e6444b9))

## [2.38.1](https://github.com/supabase/supabase-swift/compare/v2.38.0...v2.38.1) (2025-12-10)


### Bug Fixes

* **realtime:** resolve race conditions and connection bugs ([#866](https://github.com/supabase/supabase-swift/issues/866)) ([1266707](https://github.com/supabase/supabase-swift/commit/1266707c2a0926851e499935b6fd89324272c0ff))

## [2.38.0](https://github.com/supabase/supabase-swift/compare/v2.37.0...v2.38.0) (2025-12-05)


### Features

* **postgrest:** add missing operators match, imatch, and isDistinct ([#857](https://github.com/supabase/supabase-swift/issues/857)) ([af786cb](https://github.com/supabase/supabase-swift/commit/af786cb012b472dd502974c29c6817f11923901b))
* **realtime:** improve task lifecycle management and expose public APIs ([#851](https://github.com/supabase/supabase-swift/issues/851)) ([bab4ec0](https://github.com/supabase/supabase-swift/commit/bab4ec0939f719425019a623d2075110cf986059))

## [2.37.0](https://github.com/supabase/supabase-swift/compare/v2.36.0...v2.37.0) (2025-11-03)


### Features

* **auth:** add method for updating OAuth client ([#840](https://github.com/supabase/supabase-swift/issues/840)) ([a83512b](https://github.com/supabase/supabase-swift/commit/a83512bd9069201eee4af3a5f79e874db6766e87))


### Bug Fixes

* use IssueReporting ([#826](https://github.com/supabase/supabase-swift/issues/826)) ([4ebf243](https://github.com/supabase/supabase-swift/commit/4ebf2437296f75204c528218a5df23bff6f75ad4))
* **auth:** replace trait with runtime configuration flag ([#844](https://github.com/supabase/supabase-swift/pull/844)) ([e0bdfe8](https://github.com/supabase/supabase-swift/commit/e0bdfe897737e17ae9d8a6e41abfd77dbbe7db64))

## [2.36.0](https://github.com/supabase/supabase-swift/compare/v2.35.0...v2.36.0) (2025-10-15)


### Features

* **examples:** comprehensive UX overhaul with inline code examples ([#819](https://github.com/supabase/supabase-swift/issues/819)) ([70e8c18](https://github.com/supabase/supabase-swift/commit/70e8c18c52dd1efeab82030e449d5fadbd2a3d7d))


### Bug Fixes

* **auth:** emit local stored session as the initial session ([#822](https://github.com/supabase/supabase-swift/issues/822)) ([c5721fe](https://github.com/supabase/supabase-swift/commit/c5721fe540df0789239eb8497fe26acdec3c62ca))
* exclude __Snapshots__ directories from test targets ([#815](https://github.com/supabase/supabase-swift/issues/815)) ([f05a1bf](https://github.com/supabase/supabase-swift/commit/f05a1bf68f7b5091eb15c86e98af1b345681de06))

## [2.35.0](https://github.com/supabase/supabase-swift/compare/v2.34.0...v2.35.0) (2025-10-13)


### Features

* **realtime:** add explicit REST API broadcast method ([#818](https://github.com/supabase/supabase-swift/issues/818)) ([bc0d779](https://github.com/supabase/supabase-swift/commit/bc0d7790b3b836684db80196d4b65b4b259acc63))

## [2.34.0](https://github.com/supabase/supabase-swift/compare/v2.33.2...v2.34.0) (2025-10-07)


### Features

* add support for broadcast replay configuration ([#805](https://github.com/supabase/supabase-swift/issues/805)) ([8083464](https://github.com/supabase/supabase-swift/commit/8083464ad605bb99ea18df688f827ea5f417c040))
* **auth:** add OAuth 2.1 client admin endpoints ([#809](https://github.com/supabase/supabase-swift/issues/809)) ([a2320ec](https://github.com/supabase/supabase-swift/commit/a2320ec64ad8a0bb10de2fcab51822a1c5e91618))
* **auth:** introduce getClaims method to verify and extract JWT claims ([#812](https://github.com/supabase/supabase-swift/issues/812)) ([fda262b](https://github.com/supabase/supabase-swift/commit/fda262bdb0959e4f7bdb232bdec986f0fbd0f7d5))
* **functions:** add region as forceFunctionRegion query parameter ([#806](https://github.com/supabase/supabase-swift/issues/806)) ([45ec3d6](https://github.com/supabase/supabase-swift/commit/45ec3d6647c0bac26552d48fb22bffaa67fa8f0d))

## [2.33.2](https://github.com/supabase/supabase-swift/compare/v2.33.1...v2.33.2) (2025-09-25)


### Bug Fixes

* **auth:** remove session when it has been revoked ([#802](https://github.com/supabase/supabase-swift/issues/802)) ([c6aa8ef](https://github.com/supabase/supabase-swift/commit/c6aa8efef6dffc33749622168d64cbc1a422c8e2))

## [2.33.1](https://github.com/supabase/supabase-swift/compare/v2.33.0...v2.33.1) (2025-09-23)

### Bug Fixes

* **postgrest:** drop Sendable requirements in generic types ([#798](https://github.com/supabase/supabase-swift/issues/798)) ([db3f4ab](https://github.com/supabase/supabase-swift/commit/db3f4ab9de5621fdd33956e7710db0df390ddf5a))

## [2.33.0](https://github.com/supabase/supabase-swift/compare/v2.32.0...v2.33.0) (2025-09-22)

### Features

* **postgrest:** implement maxAffected method for row limit enforcement ([#795](https://github.com/supabase/supabase-swift/issues/795)) ([78fbd8a](https://github.com/supabase/supabase-swift/commit/78fbd8a0ad39e6beef1ee2a167aff799350d7275))

## [2.32.0](https://github.com/supabase/supabase-swift/compare/v2.31.2...v2.32.0) (2025-09-15)

### Features

* **auth:** implement linkIdentity with OIDC ([#776](https://github.com/supabase/supabase-swift/issues/776)) ([661e321](https://github.com/supabase/supabase-swift/commit/661e3218d18235179efc30c33b456a8f485f9ff7))

## [2.31.2](https://github.com/supabase/supabase-swift/compare/v2.31.1...v2.31.2) (2025-08-05)

### Dependencies

* bump github.com/apple/swift-crypto from 3.12.3 to 3.13.3 ([#765](https://github.com/supabase/supabase-swift/issues/765)) ([a32faf2](https://github.com/supabase/supabase-swift/commit/a32faf2))
* bump github.com/pointfreeco/swift-snapshot-testing ([#764](https://github.com/supabase/supabase-swift/issues/764)) ([8180660](https://github.com/supabase/supabase-swift/commit/8180660))
* bump github.com/pointfreeco/xctest-dynamic-overlay ([#763](https://github.com/supabase/supabase-swift/issues/763)) ([e072a58](https://github.com/supabase/supabase-swift/commit/e072a58))

## [2.31.1](https://github.com/supabase/supabase-swift/compare/v2.31.0...v2.31.1) (2025-08-01)

### Bug Fixes

* **storage:** use dedicated storage host ([#761](https://github.com/supabase/supabase-swift/issues/761)) ([9272f1e](https://github.com/supabase/supabase-swift/commit/9272f1e))
* **realtime:** make Apikey required ([#760](https://github.com/supabase/supabase-swift/issues/760)) ([237ac9c](https://github.com/supabase/supabase-swift/commit/237ac9c))

## [2.31.0](https://github.com/supabase/supabase-swift/compare/v2.30.2...v2.31.0) (2025-07-30)

### Features

* add OSLogSupabaseLogger type ([#757](https://github.com/supabase/supabase-swift/issues/757)) ([c067c52](https://github.com/supabase/supabase-swift/commit/c067c52))
* **realtime:** subscribe retry improvements ([#747](https://github.com/supabase/supabase-swift/issues/747)) ([34a70ac](https://github.com/supabase/supabase-swift/commit/34a70ac))
* migrate from release-please to semantic-release ([#748](https://github.com/supabase/supabase-swift/issues/748)) ([be133fe](https://github.com/supabase/supabase-swift/commit/be133fe))

### Bug Fixes

* **realtime:** implement event buffering for URLSessionWebSocket ([#752](https://github.com/supabase/supabase-swift/issues/752)) ([faf2d0e](https://github.com/supabase/supabase-swift/commit/faf2d0e))

### Tests

* add comprehensive Realtime test coverage ([#755](https://github.com/supabase/supabase-swift/issues/755)) ([771ee18](https://github.com/supabase/supabase-swift/commit/771ee18))

## [2.30.2](https://github.com/supabase/supabase-swift/compare/v2.30.1...v2.30.2) (2025-07-21)


### Bug Fixes

* **realtime:** wildcard event not handled in onBroadcast callback ([#749](https://github.com/supabase/supabase-swift/issues/749)) ([78b7bb4](https://github.com/supabase/supabase-swift/commit/78b7bb4f04dda49b75f46744c1aa2fe79f95d19e))

## [2.30.1](https://github.com/supabase/supabase-swift/compare/v2.30.0...v2.30.1) (2025-07-10)


### Bug Fixes

* drop Swift 5.9 ([#745](https://github.com/supabase/supabase-swift/issues/745)) ([8054bbe](https://github.com/supabase/supabase-swift/commit/8054bbe0ffa48834d20ec26d5205f6913cdde968))

## [2.30.0](https://github.com/supabase/supabase-swift/compare/v2.29.3...v2.30.0) (2025-07-03)


### Features

* **realtime:** add presence-enabled flag to join push ([#736](https://github.com/supabase/supabase-swift/issues/736)) ([7de5b8b](https://github.com/supabase/supabase-swift/commit/7de5b8b0b88a070046112026a3add7aa08b5fa3a))

## [2.29.3](https://github.com/supabase/supabase-swift/compare/v2.29.2...v2.29.3) (2025-06-10)


### Bug Fixes

* **auth:** allow to pass a Keychain storage without a service defined ([#730](https://github.com/supabase/supabase-swift/issues/730)) ([6b1d60f](https://github.com/supabase/supabase-swift/commit/6b1d60f4d3900cdbf96fd6d1be9a00711790c2ca))
* **functions:** set request timeout to 150 seconds when invoking functions ([#728](https://github.com/supabase/supabase-swift/issues/728)) ([3d2930d](https://github.com/supabase/supabase-swift/commit/3d2930d90bf5005ecf479a27a9dd7930a819e06c))

## [2.29.2](https://github.com/supabase/supabase-swift/compare/v2.29.1...v2.29.2) (2025-05-31)


### Bug Fixes

* re-export Helpers module ([#724](https://github.com/supabase/supabase-swift/issues/724)) ([fd97d99](https://github.com/supabase/supabase-swift/commit/fd97d99d780c6b6e5bff58663e8b13979853d593))

## [2.29.1](https://github.com/supabase/supabase-swift/compare/v2.29.0...v2.29.1) (2025-05-28)


### Bug Fixes

* **realtime:** make Push associated to MainActor ([#721](https://github.com/supabase/supabase-swift/issues/721)) ([7d6870f](https://github.com/supabase/supabase-swift/commit/7d6870ffa980ad3728c272acc03fc3e3c0251fe4))

## [2.29.0](https://github.com/supabase/supabase-swift/compare/v2.28.0...v2.29.0) (2025-05-20)


### Features

* **auth:** add missing auth admin methods ([#715](https://github.com/supabase/supabase-swift/issues/715)) ([04661f8](https://github.com/supabase/supabase-swift/commit/04661f86773161ec9a64feb0bcbd29b964646cfd))

## [2.28.0](https://github.com/supabase/supabase-swift/compare/v2.27.0...v2.28.0) (2025-05-03)


### Features

* add standard client headers ([#685](https://github.com/supabase/supabase-swift/issues/685)) ([ad031c7](https://github.com/supabase/supabase-swift/commit/ad031c7e14c4881b76ac1e24ef2738c8c1cf621e))

## [2.27.0](https://github.com/supabase/supabase-swift/compare/v2.26.1...v2.27.0) (2025-05-02)


### Features

* **realtime:** add heartbeat callback ([#709](https://github.com/supabase/supabase-swift/issues/709)) ([5f3d75c](https://github.com/supabase/supabase-swift/commit/5f3d75ce163df4a882975425c2c603198e2a7272))


### Bug Fixes

* **auth:** do not remove session in case of network failure ([#712](https://github.com/supabase/supabase-swift/issues/712)) ([f001b60](https://github.com/supabase/supabase-swift/commit/f001b602ddf7022e8e556ca9f8285f6cf9b3b2be))
* decoder and encoder default instances ([#711](https://github.com/supabase/supabase-swift/issues/711)) ([0104331](https://github.com/supabase/supabase-swift/commit/01043316f94c6c4a55f73442c7155389e2b15ef6))
* update outdated error doc ([#699](https://github.com/supabase/supabase-swift/issues/699)) ([b9dc3a3](https://github.com/supabase/supabase-swift/commit/b9dc3a3005968e3bd1b8348005f1f178d44dff1c))

## [2.26.1](https://github.com/supabase/supabase-swift/compare/v2.26.0...v2.26.1) (2025-03-31)


### Bug Fixes

* avoid sharing schemes with library users ([#696](https://github.com/supabase/supabase-swift/issues/696)) ([3caa69f](https://github.com/supabase/supabase-swift/commit/3caa69fa8fb71eb8c4d89dac8ba498a9782b26fc))

## [2.26.0](https://github.com/supabase/supabase-swift/compare/v2.25.0...v2.26.0) (2025-03-06)


### Features

* add Android support ([#673](https://github.com/supabase/supabase-swift/issues/673)) ([6ec2cdd](https://github.com/supabase/supabase-swift/commit/6ec2cdd994f80cc754f310b4aaf307671454f992))


### Bug Fixes

* **auth:** add missing `@MainActor` ([#684](https://github.com/supabase/supabase-swift/issues/684)) ([16ffdd4](https://github.com/supabase/supabase-swift/commit/16ffdd4a2f996626be8cb595ab6f31d94e8eeb4b))

## [2.25.0](https://github.com/supabase/supabase-swift/compare/v2.24.7...v2.25.0) (2025-02-20)


### Features

* **realtime:** add predefined filters instead of regular `String` ([#669](https://github.com/supabase/supabase-swift/issues/669)) ([3dc9b82](https://github.com/supabase/supabase-swift/commit/3dc9b82e90a5158664d163caeb397e220f58d8dd))

## [2.24.7](https://github.com/supabase/supabase-swift/compare/v2.24.6...v2.24.7) (2025-02-18)


### Bug Fixes

* **realtime:** Set default heartbeat interval to 25s ([#667](https://github.com/supabase/supabase-swift/issues/667)) ([14c590d](https://github.com/supabase/supabase-swift/commit/14c590d08898e5a3c1c131ad704966d73df7e538))

## [2.24.6](https://github.com/supabase/supabase-swift/compare/v2.24.5...v2.24.6) (2025-02-14)


### Bug Fixes

* **auth:** make AuthClient an Actor ([#664](https://github.com/supabase/supabase-swift/issues/664)) ([bdf1961](https://github.com/supabase/supabase-swift/commit/bdf19614b35b76281f2a50e785b6d21fa9578e40))

## [2.24.5](https://github.com/supabase/supabase-swift/compare/v2.24.4...v2.24.5) (2025-02-10)


### Bug Fixes

* **realtime:** remove jwt check ([#658](https://github.com/supabase/supabase-swift/issues/658)) ([4c95559](https://github.com/supabase/supabase-swift/commit/4c955592c58c7d0aafbd0c32ae8a85e213303caa))

## [2.24.4](https://github.com/supabase/supabase-swift/compare/v2.24.3...v2.24.4) (2025-01-16)


### Bug Fixes

* Make the return value of accessToken nullable ([#641](https://github.com/supabase/supabase-swift/issues/641)) ([af9b774](https://github.com/supabase/supabase-swift/commit/af9b77453892da562c444e94ff7538051a2dd0a4))

## [2.24.3](https://github.com/supabase/supabase-swift/compare/v2.24.2...v2.24.3) (2025-01-14)


### Bug Fixes

* remove usage of `nonisolated(unsafe)` from codebase ([#638](https://github.com/supabase/supabase-swift/issues/638)) ([3d87608](https://github.com/supabase/supabase-swift/commit/3d876089b2429389f0e16e4238cc11bd444a1254))

## [2.24.2](https://github.com/supabase/supabase-swift/compare/v2.24.1...v2.24.2) (2025-01-08)


### Bug Fixes

* **realtime:** auto reconnect after calling disconnect, and several refactors ([#627](https://github.com/supabase/supabase-swift/issues/627)) ([1887f4f](https://github.com/supabase/supabase-swift/commit/1887f4f376e172bb7fbcec84506fea6c4797fde7))

## [2.24.1](https://github.com/supabase/supabase-swift/compare/v2.24.0...v2.24.1) (2024-12-16)


### Bug Fixes

* **auth:** add missing channel param to signUp method ([#625](https://github.com/supabase/supabase-swift/issues/625)) ([3a36ab7](https://github.com/supabase/supabase-swift/commit/3a36ab74c4fbd9224c03dabd88046bba49b0de9c))

## [2.24.0](https://github.com/supabase/supabase-swift/compare/v2.23.0...v2.24.0) (2024-12-05)


### Features

* **realtime:** pull access token mechanism ([#615](https://github.com/supabase/supabase-swift/issues/615)) ([c88dd36](https://github.com/supabase/supabase-swift/commit/c88dd3675b8bc7da93c71847ff9ba9862323ff8d))


### Bug Fixes

* **realtime:** prevent sending expired tokens ([#618](https://github.com/supabase/supabase-swift/issues/618)) ([595277b](https://github.com/supabase/supabase-swift/commit/595277b5eb35b8b76bbb000d44fc221c4d3298f1))

## [2.23.0](https://github.com/supabase/supabase-swift/compare/v2.22.1...v2.23.0) (2024-11-22)


### Features

* **postgrest:** add read-only mode for RPC ([#600](https://github.com/supabase/supabase-swift/issues/600)) ([d81fc86](https://github.com/supabase/supabase-swift/commit/d81fc865409821dc0816c930d2d537a126b4fe06))

## [2.22.1](https://github.com/supabase/supabase-swift/compare/v2.22.0...v2.22.1) (2024-11-12)


### Bug Fixes

* **auth:** `URLError` coercion for `RetryableError` causing session to be deleted ([#597](https://github.com/supabase/supabase-swift/issues/597)) ([d67b7cf](https://github.com/supabase/supabase-swift/commit/d67b7cf850d43c2a8ecf39feedfc39528f55f139))

## [2.22.0](https://github.com/supabase/supabase-swift/compare/v2.21.0...v2.22.0) (2024-11-06)


### Features

* **auth:** add new error codes ([#586](https://github.com/supabase/supabase-swift/issues/586)) ([1721c08](https://github.com/supabase/supabase-swift/commit/1721c08c7710e0cba1390962441fe595b613072c))


### Bug Fixes

* **auth:** incorrect error when error occurs during PKCE flow ([#592](https://github.com/supabase/supabase-swift/issues/592)) ([84ce6f2](https://github.com/supabase/supabase-swift/commit/84ce6f29b2ee2192b57d8ff7c36af3378c696653))

## [2.21.0](https://github.com/supabase/supabase-swift/compare/v2.20.5...v2.21.0) (2024-11-05)


### Features

* **realtime:** add `system` event ([#589](https://github.com/supabase/supabase-swift/issues/589)) ([1176dea](https://github.com/supabase/supabase-swift/commit/1176dea4d90f353ae777a633fc079dedf98276ff))


### Bug Fixes

* **realtime:** lost `postgres_changes` on resubscribe ([#585](https://github.com/supabase/supabase-swift/issues/585)) ([fabc07d](https://github.com/supabase/supabase-swift/commit/fabc07dac833aa94e35bf932899dfb5d1a868cfb))

## [2.20.5](https://github.com/supabase/supabase-swift/compare/v2.20.4...v2.20.5) (2024-10-24)


### Bug Fixes

* issue with MainActor isolated property on Swift 5.9 ([#577](https://github.com/supabase/supabase-swift/issues/577)) ([7266b64](https://github.com/supabase/supabase-swift/commit/7266b64e1e0b58fc893693fa80872b6d77bf1555))
* revert AnyJSON codable ([#580](https://github.com/supabase/supabase-swift/issues/580)) ([bfb6ed7](https://github.com/supabase/supabase-swift/commit/bfb6ed7b9b69123dc5cc16458da62ee3546eaf98))

## [2.20.4](https://github.com/supabase/supabase-swift/compare/v2.20.3...v2.20.4) (2024-10-23)


### Bug Fixes

* **storage:** cache control ([#551](https://github.com/supabase/supabase-swift/issues/551)) ([8a2b196](https://github.com/supabase/supabase-swift/commit/8a2b19690cf165c80454ff6388cb9a202b04172c))

## [2.20.3](https://github.com/supabase/supabase-swift/compare/v2.20.2...v2.20.3) (2024-10-22)


### Bug Fixes

* remove kSecUseDataProtectionKeychain ([#574](https://github.com/supabase/supabase-swift/issues/574)) ([554f916](https://github.com/supabase/supabase-swift/commit/554f91689eb13c1a923a53bddb5d194e6b80328a))

## [2.20.2](https://github.com/supabase/supabase-swift/compare/v2.20.1...v2.20.2) (2024-10-17)


### Bug Fixes

* general auth improvements ([#561](https://github.com/supabase/supabase-swift/issues/561)) ([5f4c0f2](https://github.com/supabase/supabase-swift/commit/5f4c0f256c74beb47ce2a42951014504ba798dd6))
* replace to HTTPTypes Components from Helpers Components ([#564](https://github.com/supabase/supabase-swift/issues/564)) ([71dee2a](https://github.com/supabase/supabase-swift/commit/71dee2ac35204c40e11d7aa3c3c6f5def95520f9))
* Swift 6 now has URLSession async method ([#565](https://github.com/supabase/supabase-swift/issues/565)) ([5786dd6](https://github.com/supabase/supabase-swift/commit/5786dd6c06ceead5851fb6527a48d0cee48654af))

## [2.20.1](https://github.com/supabase/supabase-swift/compare/v2.20.0...v2.20.1) (2024-10-09)


### Bug Fixes

* **realtime:** add RealtimeSubscription and deprecate Subscription ([#542](https://github.com/supabase/supabase-swift/issues/542)) ([3a44f30](https://github.com/supabase/supabase-swift/commit/3a44f306f32aaf0a096c316f02995f0de649b991))
* **realtime:** allow to nullify access token ([45273e5](https://github.com/supabase/supabase-swift/commit/45273e5325f57c040030901cb269fff5c0a66974))
* **realtime:** deprecate `updateAuth` from channel ([45273e5](https://github.com/supabase/supabase-swift/commit/45273e5325f57c040030901cb269fff5c0a66974))
* Swift 6 warnings related to `@_unsafeInheritExecutor` attribute ([#549](https://github.com/supabase/supabase-swift/issues/549)) ([eab7a4a](https://github.com/supabase/supabase-swift/commit/eab7a4a7a494cfdf354ecd16373bbc05d4a0977f))

## [2.20.0](https://github.com/supabase/supabase-swift/compare/v2.19.0...v2.20.0) (2024-09-25)


### Features

* **storage:** add info, exists, custom metadata, and methods for uploading file URL ([#510](https://github.com/supabase/supabase-swift/issues/510)) ([d9ba673](https://github.com/supabase/supabase-swift/commit/d9ba673b882c84e5fae277510d147f52e22b861b))

## [2.19.0](https://github.com/supabase/supabase-swift/compare/v2.18.0...v2.19.0) (2024-09-24)


### Features

* **auth:** add listUsers admin method ([#539](https://github.com/supabase/supabase-swift/issues/539)) ([1851262](https://github.com/supabase/supabase-swift/commit/1851262b5c4eb8247c10e768be3f9110938db892))


### Bug Fixes

* **realtime:** add missing `onPostgresChange` overload ([#528](https://github.com/supabase/supabase-swift/issues/528)) ([95e249f](https://github.com/supabase/supabase-swift/commit/95e249f135702c502ac8c0edc7f437337458796b))

## [2.18.0](https://github.com/supabase/supabase-swift/compare/v2.17.1...v2.18.0) (2024-09-07)


### Features

* **auth:** add support for error codes and refactor `AuthError` ([#518](https://github.com/supabase/supabase-swift/issues/518)) ([7601e17](https://github.com/supabase/supabase-swift/commit/7601e17aa87cd832aee125095a89db2175364e35))


### Bug Fixes

* **functions:** fix streamed responses ([#525](https://github.com/supabase/supabase-swift/issues/525)) ([0631069](https://github.com/supabase/supabase-swift/commit/0631069ec71cfce0e1a56bb386a679c72e862c48))

## [2.17.1](https://github.com/supabase/supabase-swift/compare/v2.17.0...v2.17.1) (2024-09-02)


### Bug Fixes

* **auth:** expose KeychainLocalStorage with default init params ([#519](https://github.com/supabase/supabase-swift/issues/519)) ([c1095c9](https://github.com/supabase/supabase-swift/commit/c1095c95a2b01a3ad76a996e6c81ed8b25dab214))

## [2.17.0](https://github.com/supabase/supabase-swift/compare/v2.16.1...v2.17.0) (2024-08-28)


### Features

* **postgrest:** set header on a per call basis ([#508](https://github.com/supabase/supabase-swift/issues/508)) ([a15efb1](https://github.com/supabase/supabase-swift/commit/a15efb15a26c76d4bbc13e570c4841633ccd6177))
* **postgrest:** use `Date` when filtering columns ([#514](https://github.com/supabase/supabase-swift/issues/514)) ([1b0155c](https://github.com/supabase/supabase-swift/commit/1b0155c3d35c23ccefceffbb13eb36f2c5ec513f))


### Bug Fixes

* **auth:** store session directly without wrapping in StoredSession type ([#513](https://github.com/supabase/supabase-swift/issues/513)) ([5de2d8d](https://github.com/supabase/supabase-swift/commit/5de2d8da722183a3be80bfddd48637932e9cbc23))

## [2.16.1](https://github.com/supabase/supabase-swift/compare/v2.16.0...v2.16.1) (2024-08-14)


### Bug Fixes

* **auth:** auth event emitter being shared among clients ([#500](https://github.com/supabase/supabase-swift/issues/500)) ([83f3385](https://github.com/supabase/supabase-swift/commit/83f338502a242691bc6455819fc0599c5e2021c1))
* **auth:** store code verifier in keychain ([#502](https://github.com/supabase/supabase-swift/issues/502)) ([b86154a](https://github.com/supabase/supabase-swift/commit/b86154a9aa808f40f87de39e32cf48e40534662e))

## [2.16.0](https://github.com/supabase/supabase-swift/compare/v2.15.3...v2.16.0) (2024-08-12)


### Features

* **auth:** add MFA phone ([#496](https://github.com/supabase/supabase-swift/issues/496)) ([2e445f2](https://github.com/supabase/supabase-swift/commit/2e445f24ba1856dd7ebb57dfabbba45ec1e0f118))

## [2.15.3](https://github.com/supabase/supabase-swift/compare/v2.15.2...v2.15.3) (2024-08-06)


### Bug Fixes

* **auth:** add missing figma, kakao, linkedin_oidc, slack_oidc, zoom, and fly providers ([#493](https://github.com/supabase/supabase-swift/issues/493)) ([152f5ce](https://github.com/supabase/supabase-swift/commit/152f5ce8e14dd54ad70ab0184d9dcb9ead65d824))

## [2.15.2](https://github.com/supabase/supabase-swift/compare/v2.15.1...v2.15.2) (2024-07-30)


### Bug Fixes

* **auth:** mark identities last_sign_in_at field as optional ([#483](https://github.com/supabase/supabase-swift/issues/483)) ([c93cf90](https://github.com/supabase/supabase-swift/commit/c93cf90d60d7d6ed1ff04a6a51e72ab009f30795))

## [2.15.1](https://github.com/supabase/supabase-swift/compare/v2.15.0...v2.15.1) (2024-07-30)


### Bug Fixes

* **storage:** list folders ([#454](https://github.com/supabase/supabase-swift/issues/454)) ([4e9f52a](https://github.com/supabase/supabase-swift/commit/4e9f52a0257a8b6e747854a53553421322a947df))

## [2.15.0](https://github.com/supabase/supabase-swift/compare/v2.14.3...v2.15.0) (2024-07-29)


### Features

* add third-party auth support ([#423](https://github.com/supabase/supabase-swift/issues/423)) ([d760f2d](https://github.com/supabase/supabase-swift/commit/d760f2d28373e80c16e8e256bf2491780a820afc))
* **realtime:** send broadcast events through HTTP ([#476](https://github.com/supabase/supabase-swift/issues/476)) ([93f4ff5](https://github.com/supabase/supabase-swift/commit/93f4ff5d3504ec5cac7e51bff4923dab51adb04b))

## [2.14.3](https://github.com/supabase/supabase-swift/compare/v2.14.2...v2.14.3) (2024-07-19)


### Bug Fixes

* **realtime:** crash when connecting socket ([#470](https://github.com/supabase/supabase-swift/issues/470)) ([5cf4f56](https://github.com/supabase/supabase-swift/commit/5cf4f563c0cbc551d8e60f5e7f8a45034644580c))

## [2.14.2](https://github.com/supabase/supabase-swift/compare/v2.14.1...v2.14.2) (2024-07-13)


### Bug Fixes

* **postgrest:** avoid duplicated columns and prefer fields ([#463](https://github.com/supabase/supabase-swift/issues/463)) ([e4f85f3](https://github.com/supabase/supabase-swift/commit/e4f85f3512ce06e85d8ca2922f0a4ca011079c21))

## [2.14.1](https://github.com/supabase/supabase-swift/compare/v2.14.0...v2.14.1) (2024-07-11)


### Bug Fixes

* **auth:** add missing nonce param when updating user ([#457](https://github.com/supabase/supabase-swift/issues/457)) ([a087a6a](https://github.com/supabase/supabase-swift/commit/a087a6a872f0540f163e89bcab6839d0f1695fd8))
* **auth:** prevent from requesting login keychain password os macOS ([#455](https://github.com/supabase/supabase-swift/issues/455)) ([3e45b5a](https://github.com/supabase/supabase-swift/commit/3e45b5a79f7a33e7752102c31730b7604292cb89))

## [2.14.0](https://github.com/supabase/supabase-swift/compare/v2.13.9...v2.14.0) (2024-07-09)


### Features

* **auth:** add support for multiple auth instances ([#445](https://github.com/supabase/supabase-swift/issues/445)) ([6803ddd](https://github.com/supabase/supabase-swift/commit/6803ddd02aa02b34ee093725611710da4f7671c1))


### Bug Fixes

* **auth:** verify otp using token hash ([#451](https://github.com/supabase/supabase-swift/issues/451)) ([58ab9af](https://github.com/supabase/supabase-swift/commit/58ab9afb152d3701a63009cc83c392f97e5bdea1))

## [2.13.9](https://github.com/supabase/supabase-swift/compare/v2.13.8...v2.13.9) (2024-07-06)


### Bug Fixes

* expose SupabaseClient headers ([#447](https://github.com/supabase/supabase-swift/issues/447)) ([50fc325](https://github.com/supabase/supabase-swift/commit/50fc32501fe6fc229841f35511b672cd29364aaa))

## [2.13.8](https://github.com/supabase/supabase-swift/compare/v2.13.7...v2.13.8) (2024-07-04)


### Bug Fixes

* Add private topic to Realtime ([#442](https://github.com/supabase/supabase-swift/issues/442)) ([a491b29](https://github.com/supabase/supabase-swift/commit/a491b297ca4cf965e554632d0a9be4052844d6a8))

## [2.13.7](https://github.com/supabase/supabase-swift/compare/v2.13.6...v2.13.7) (2024-07-02)


### Bug Fixes

* **realtime:** send access token to realtime on initial session ([#439](https://github.com/supabase/supabase-swift/issues/439)) ([048e81b](https://github.com/supabase/supabase-swift/commit/048e81b9ca5a317ad4340c4bae60f556d9e31584))

## [2.13.6](https://github.com/supabase/supabase-swift/compare/v2.13.5...v2.13.6) (2024-07-01)


### Bug Fixes

* date formatter breaking change ([#435](https://github.com/supabase/supabase-swift/issues/435)) ([6b4cc2e](https://github.com/supabase/supabase-swift/commit/6b4cc2e7fc3b61960449a15d36ef732c8020f222))

## [2.13.5](https://github.com/supabase/supabase-swift/compare/v2.13.4...v2.13.5) (2024-06-28)


### Bug Fixes

* **auth:** use project ref as namespace for storing token ([#430](https://github.com/supabase/supabase-swift/issues/430)) ([82fa93d](https://github.com/supabase/supabase-swift/commit/82fa93d0c19de6baa6de4b02dd0cdf3a17a3f0cd))

## [2.13.4](https://github.com/supabase/supabase-swift/compare/v2.13.3...v2.13.4) (2024-06-28)


### Bug Fixes

* concurrency warnings pre swift 6 support ([#428](https://github.com/supabase/supabase-swift/issues/428)) ([bee6fa7](https://github.com/supabase/supabase-swift/commit/bee6fa70182cd750d4a9c2c107bc143470c4108b))
* **realtime:** revert realtime token to apikey on user sign out ([#429](https://github.com/supabase/supabase-swift/issues/429)) ([11c629f](https://github.com/supabase/supabase-swift/commit/11c629fce23ddc3ae82ba8f04814cb0841af0ae3))

## [2.13.3](https://github.com/supabase/supabase-swift/compare/v2.13.2...v2.13.3) (2024-06-17)


### Bug Fixes

* **realtime:** Adds missing `.unsubscribed` status change ([#420](https://github.com/supabase/supabase-swift/issues/420)) ([dc90fb6](https://github.com/supabase/supabase-swift/commit/dc90fb675e9b9ccf7733d28a4fcfc3e59416e119))

## [2.13.2](https://github.com/supabase/supabase-swift/compare/v2.13.1...v2.13.2) (2024-06-07)


### Bug Fixes

* **auth:** don't call removeSession prematurely ([#416](https://github.com/supabase/supabase-swift/issues/416)) ([00221a8](https://github.com/supabase/supabase-swift/commit/00221a84fbf026ab41911d23be01e8065a949989))

## [2.13.1](https://github.com/supabase/supabase-swift/compare/v2.13.0...v2.13.1) (2024-06-06)


### Bug Fixes

* **auth:** missing autoRefreshToken param in initializer ([#415](https://github.com/supabase/supabase-swift/issues/415)) ([32de22f](https://github.com/supabase/supabase-swift/commit/32de22ffa775bfc45f4077330de3dbe81b327f3e))
* invalid identifier for _Helpers target ([#414](https://github.com/supabase/supabase-swift/issues/414)) ([b2c8aee](https://github.com/supabase/supabase-swift/commit/b2c8aee894c7a9c729d66bd850f4ffa706a21ae3))

## [2.13.0](https://github.com/supabase/supabase-swift/compare/v2.12.0...v2.13.0) (2024-06-04)


### Features

* **auth:** add convenience deep link handling methods ([#397](https://github.com/supabase/supabase-swift/issues/397)) ([db7a094](https://github.com/supabase/supabase-swift/commit/db7a0949d2e2a7a16f0d684e11d569b7ad0bee8e))
* **auth:** add options for disabling auto refresh token ([#411](https://github.com/supabase/supabase-swift/issues/411)) ([24f6a76](https://github.com/supabase/supabase-swift/commit/24f6a7683f8154b6f7a0c80b6324717efdd95c76))
* improve logging on token refresh logic ([#410](https://github.com/supabase/supabase-swift/issues/410)) ([a8ed053](https://github.com/supabase/supabase-swift/commit/a8ed053c96eaf69146dc40bbec7702fe88077354))
* **storage:** fill content-type based on file extension ([#400](https://github.com/supabase/supabase-swift/issues/400)) ([569f445](https://github.com/supabase/supabase-swift/commit/569f4455bbde6e6ea1c6a7f630a1e1d66dc39bb0))


### Bug Fixes

* **realtime:** handle timeout when subscribing to channel ([#349](https://github.com/supabase/supabase-swift/issues/349)) ([a222dd4](https://github.com/supabase/supabase-swift/commit/a222dd4aad072917d44ba18232bb32c01b5e1c18))

## [2.12.0](https://github.com/supabase/supabase-swift/compare/v2.11.0...v2.12.0) (2024-05-26)


### Features

* **auth:** add isExpired variable to session type ([#399](https://github.com/supabase/supabase-swift/issues/399)) ([dcada1a](https://github.com/supabase/supabase-swift/commit/dcada1accae66793e0f4e046dd8620870b93b3dd))
* **auth:** retry auth requests, and schedule next refresh retry in background ([#395](https://github.com/supabase/supabase-swift/issues/395)) ([35ac278](https://github.com/supabase/supabase-swift/commit/35ac2784a71edbfcaf9bc3d9dab5f721c5ea2ba6))


### Bug Fixes

* manually percent encode query items to allow values with + sign ([#402](https://github.com/supabase/supabase-swift/issues/402)) ([a0ecb70](https://github.com/supabase/supabase-swift/commit/a0ecb70804f2a97aecb66499afad8ec3370815c6))
* **storage:** list method using wrong encoder ([#405](https://github.com/supabase/supabase-swift/issues/405)) ([f16989a](https://github.com/supabase/supabase-swift/commit/f16989a5b5bd5c6d769bfaff7e6ae076dc2d3ba5))

## [2.11.0](https://github.com/supabase/supabase-swift/compare/v2.10.1...v2.11.0) (2024-05-18)


### Features

* **auth:** add linkIdentity method ([#392](https://github.com/supabase/supabase-swift/issues/392)) ([7dfaa46](https://github.com/supabase/supabase-swift/commit/7dfaa466e305eb4e29fe7b8472c362bdeba6fa45))

## [2.10.1](https://github.com/supabase/supabase-swift/compare/v2.10.0...v2.10.1) (2024-05-15)


### Bug Fixes

* race condition when accessing SupabaseClient ([#386](https://github.com/supabase/supabase-swift/issues/386)) ([811e222](https://github.com/supabase/supabase-swift/commit/811e222dd486625eb9ba8937be139563bdc10d43))

## [2.10.0](https://github.com/supabase/supabase-swift/compare/v2.9.0...v2.10.0) (2024-05-14)


### Features

* expose Realtime options on SupabaseClient ([#377](https://github.com/supabase/supabase-swift/issues/377)) ([9cfafdb](https://github.com/supabase/supabase-swift/commit/9cfafdbb4a321dd523f33319bdd7e69e8d77a0ea))


### Bug Fixes

* **auth:** adds missing redirectTo query item to updateUser ([#380](https://github.com/supabase/supabase-swift/issues/380)) ([5d1a997](https://github.com/supabase/supabase-swift/commit/5d1a9970a2024a686a013873cb70eaae64ba4aa6))
* **auth:** header being overridden ([#379](https://github.com/supabase/supabase-swift/issues/379)) ([866a039](https://github.com/supabase/supabase-swift/commit/866a0395043030dd1574deb97360e2d47040efae))
* **postgrest:** update parameter of `is` filter to allow only `Bool` or `nil` ([#382](https://github.com/supabase/supabase-swift/issues/382)) ([4ba1c7a](https://github.com/supabase/supabase-swift/commit/4ba1c7a6c5a13c0a2b4b067aad5c747d7d621e93))
* **storage:** headers overridden ([#384](https://github.com/supabase/supabase-swift/issues/384)) ([b40c34a](https://github.com/supabase/supabase-swift/commit/b40c34a63fbbc0760d3f6e70ed7b69b08f9e70c8))

## [2.9.0](https://github.com/supabase/supabase-swift/compare/v2.8.5...v2.9.0) (2024-05-10)


### Features

* **auth:** Adds `currentSession` and `currentUser` properties ([#373](https://github.com/supabase/supabase-swift/issues/373)) ([4b01556](https://github.com/supabase/supabase-swift/commit/4b015565edbdb761ead8294ebb66d05da5a48b59))
* **functions:** invoke function with custom query params ([#376](https://github.com/supabase/supabase-swift/issues/376)) ([b4b9276](https://github.com/supabase/supabase-swift/commit/b4b9276512acccc673c36e35f06e69755e2a5dc7))
* improve HTTP Error ([#372](https://github.com/supabase/supabase-swift/issues/372)) ([ea25236](https://github.com/supabase/supabase-swift/commit/ea252365511773f93ef35bc2aa80c6098612de57))
* **storage:** copy objects between buckets ([69d05ef](https://github.com/supabase/supabase-swift/commit/69d05eff5dbb413b8b2a5ba565f7f5e19a6e0ab6))
* **storage:** move objects between buckets ([69d05ef](https://github.com/supabase/supabase-swift/commit/69d05eff5dbb413b8b2a5ba565f7f5e19a6e0ab6))


### Bug Fixes

* **auth:** sign out regardless of request success ([#375](https://github.com/supabase/supabase-swift/issues/375)) ([25178e2](https://github.com/supabase/supabase-swift/commit/25178e212dcc0dba4a712e9b7ec3ed93575efdf9))

## [2.8.5](https://github.com/supabase/supabase-swift/compare/v2.8.4...v2.8.5) (2024-05-08)


### Bug Fixes

* throw generic HTTPError ([#368](https://github.com/supabase/supabase-swift/issues/368)) ([782e940](https://github.com/supabase/supabase-swift/commit/782e940437a8a72d3243847c04fb37ef2f5fe7f0))

## [2.8.4](https://github.com/supabase/supabase-swift/compare/v2.8.3...v2.8.4) (2024-05-08)


### Bug Fixes

* **functions:** invoke with custom http method ([#367](https://github.com/supabase/supabase-swift/issues/367)) ([a283b68](https://github.com/supabase/supabase-swift/commit/a283b68cf49faa4c5bd2bb870e0840900fc7af35))

## [2.8.3](https://github.com/supabase/supabase-swift/compare/v2.8.2...v2.8.3) (2024-05-07)


### Bug Fixes

* **auth:** extract both query and fragment from URL ([#365](https://github.com/supabase/supabase-swift/issues/365)) ([e9c7c8c](https://github.com/supabase/supabase-swift/commit/e9c7c8c29002c9be1bf523deefc25e036d3c4a2a))

## [2.8.2](https://github.com/supabase/supabase-swift/compare/v2.8.1...v2.8.2) (2024-05-06)


### Bug Fixes

* **auth:** sign out should ignore 403s ([#359](https://github.com/supabase/supabase-swift/issues/359)) ([7c4e62b](https://github.com/supabase/supabase-swift/commit/7c4e62b3d0dcc6f307639abb3ef8ad792589fab1))

## [2.8.1](https://github.com/supabase/supabase-swift/compare/v2.8.0...v2.8.1) (2024-04-29)


### Bug Fixes

* **auth:** add missing is_anonymous field ([#355](https://github.com/supabase/supabase-swift/issues/355)) ([854dc42](https://github.com/supabase/supabase-swift/commit/854dc42659ed9c634271562b93169bb82e06890e))

## [2.8.0](https://github.com/supabase/supabase-swift/compare/v2.7.0...v2.8.0) (2024-04-22)


### Features

* **functions:** add experimental invoke with streamed responses ([#346](https://github.com/supabase/supabase-swift/issues/346)) ([2611b09](https://github.com/supabase/supabase-swift/commit/2611b091c871cf336de954f169240647efdf0339))
* **functions:** add support for specifying function region ([#347](https://github.com/supabase/supabase-swift/issues/347)) ([f470874](https://github.com/supabase/supabase-swift/commit/f470874f8dd8b0077a44e7243fc1d91993ae5fa9))
* **postgrest:** add geojson, explain, and new filters ([#343](https://github.com/supabase/supabase-swift/issues/343)) ([56c8117](https://github.com/supabase/supabase-swift/commit/56c81171d1e610e0286f7122522890d2b4001c2b))
* **realtime:** add closure based methods ([#345](https://github.com/supabase/supabase-swift/issues/345)) ([dfe09bc](https://github.com/supabase/supabase-swift/commit/dfe09bc804a06a06743884cbf56c5890409e9a87))


### Bug Fixes

* linux build ([#350](https://github.com/supabase/supabase-swift/issues/350)) ([e62ad89](https://github.com/supabase/supabase-swift/commit/e62ad891c80b037aada972f7c11e806f70c6aa50))
* **storage:** getSignedURLs method using wrong encoder ([#352](https://github.com/supabase/supabase-swift/issues/352)) ([d1b0672](https://github.com/supabase/supabase-swift/commit/d1b06728670ed2bb204693f69a81e584cd5c1a73))

## [2.7.0](https://github.com/supabase/supabase-swift/compare/v2.6.0...v2.7.0) (2024-04-16)


### Features

* **auth:** add `getLinkIdentityURL` ([#342](https://github.com/supabase/supabase-swift/issues/342)) ([202383d](https://github.com/supabase/supabase-swift/commit/202383d355dfaa9aab0e03680d9fedb9bdfc02d9))
* **auth:** add `signInWithOAuth` ([#299](https://github.com/supabase/supabase-swift/issues/299)) ([1290bcf](https://github.com/supabase/supabase-swift/commit/1290bcfb39fb156de0283888b47ba1532107f468))
* expose PostgrestClient methods directly in SupabaseClient ([#336](https://github.com/supabase/supabase-swift/issues/336)) ([aca50a5](https://github.com/supabase/supabase-swift/commit/aca50a557339f9872896b03988b737c56589fba7))


### Bug Fixes

* **postgrest:** race condition when executing request ([#327](https://github.com/supabase/supabase-swift/issues/327)) ([8063610](https://github.com/supabase/supabase-swift/commit/80636105e154a28f418f01f4af8b30987239b8f3))
* **postgrest:** race condition when setting fetchOptions and execute method call ([#325](https://github.com/supabase/supabase-swift/issues/325)) ([97d1900](https://github.com/supabase/supabase-swift/commit/97d1900d26272777f864803a0290573b39f47f00))

## [2.6.0](https://github.com/supabase-community/supabase-swift/compare/2.5.1...v2.6.0) (2024-04-03)


### Features

* **auth:** Add `signInAnonymously` ([#297](https://github.com/supabase-community/supabase-swift/issues/297)) ([4c25a3e](https://github.com/supabase-community/supabase-swift/commit/4c25a3eac392b319154ffb3d5d33a0686e3781a4))
